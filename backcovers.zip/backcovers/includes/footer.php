  <link href="css/bootstrap.css" rel='stylesheet' type='text/css' /><link href="css/style.css" rel='stylesheet' type='text/css' />
        
		<div class="footer">
			<div class="container">
				<div class="row">
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>Products</h4>
							<li><a href="appleshop.php">APPLE</a></li>
							<li><a href="samsungshop.php">SAMSUNG</a></li>
							<li><a href="huaweishop.php">HUAWEI</a></li>
                            <li><a href="sonyshop.php">SONY</a></li>
                            <li><a href="nokiashop.php">NOKIA</a></li>
							<li><a href="othershop.php">OTHER</a></li>

						</ul>
					</div>
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>About</h4>
                            <b><p>SRI LANKAS’ 1ST AND BEST BACKOVERS AND PHONE CASES SELLING SITE.</p></b>
							<!--<li><a href="#">Jobs</a></li>
							<li><a href="#">Discounts</a></li>
							<li><a href="#">team</a></li>
							<li><a href="#">Catalog Request/Download</a></li>-->
						</ul>
					</div>
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>Customer Support</h4>
							<li><a href="connect.php">Contact Us</a></li>
							<li><a href="#">Easy Returns</a></li>
						</ul>
					</div>
					<div class="col-md-3">						<ul class="footer_box">							<h4>Follow Us</h4>							<div class="footer_search">				    <!--		   <form>				    			<input type="text" value="Enter your email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter your email';}">				    			<input type="submit" value="Go">				    		   </form>  -->					        </div>							<ul class="social">								  <div class="fb-like" data-href="https://www.facebook.com/Hackmeplz-1413106622056661/?ref=br_rs" data-layout="standard" data-action="like" data-size="large" data-show-faces="true" data-share="true"></div>									  										    </ul>		   											</ul>					</div>
				</div>
				<div class="row footer_bottom">
				    <div class="copy">
                        <p>Developed by <a href="http://tresetsolutions.com/" target="_blank"> Treset Solutions </a>© 2017 www.BackCovers.lk. All rights reserved | Delivery : 0777 262 721</p>
		            </div>
   				</div>
			</div>
		</div>
		<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.10';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>




