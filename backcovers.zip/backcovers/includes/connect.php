<?php

$db_name="backcovers.lk";
$mysql_username="root";
$mysql_password="";
$server_name="localhost";
$connection=mysqli_connect($server_name,$mysql_username,$mysql_password,$db_name);




/*


$db_name="id2877070_backcovers";
$mysql_username="id2877070_backcovers";
$mysql_password="12345";
$server_name="localhost";
$connection=mysqli_connect($server_name,$mysql_username,$mysql_password,$db_name);


*/





?> 
